package com.assignment.java.week8;

public class consumer {

	Thread1 t1;

	consumer(Thread1 t1) {
		this.t1 = t1;
	}
}
